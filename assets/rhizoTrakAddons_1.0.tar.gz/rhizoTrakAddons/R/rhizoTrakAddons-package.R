#' @keywords internal
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end

#' rhizoTrakAddons: Analyse and process root annotations created with rhizoTrak
#'
#' @name rhizoTrakAddons
#' @docType package
