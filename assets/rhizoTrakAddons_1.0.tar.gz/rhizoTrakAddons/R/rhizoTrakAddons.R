library(dplyr)

#' Get all rootIDs
#'
#' Get all unique rootIds in the data frame
#'
#' @param segDF  data frame read from the experimental data annotated with rhizoTrak in Detailed mode
#'
#' @return Vector of all rootIDs
#' @export
rtkGetRootIDs <- function( segDF) {
  unique( segDF$rootID)
}

#' Get status labels
#'
#' Get all status label integers and status names define in the data frame
#'
#' @param segDF data frame read from the experimental data annotated with rhizoTrak in Detailed mode
#'
#' @return data frame with all status label integers and status names
#' @export
rtkGetStatusLabels <- function( segDF) {
  segDF %>% select( .data$status, .data$statusName) %>% unique
}

#' Get status label name for status label integer
#'
#' @param segDF data frame read from the experimental data annotated with rhizoTrak in Detailed mode
#' @param status status label integer
#'
#' @return status label name or NULL if none found or not unique
#' @export
rtkGetNameForStatus <- function( segDF, status) {
  sls <- rtkGetStatusLabels( segDF)
  res <- sls$statusName[sls$status==status]
  if ( length(res) == 1) {
    res
  } else {
    NULL
  }
}

#' Get status label integer for a status label name
#'
#' @param segDF data frame read from the experimental data annotated with rhizoTrak in Detailed mode
#' @param statusName status nake to look up
#'
#' @return status label integer or NULL if none found or not unique
#' @export
rtkGetStatusForName <- function( segDF, statusName) {
  sls <- rtkGetStatusLabels( segDF)
  sn <-
  res <- sls$status[sls$statusName==statusName]
  if ( length(res) == 1) {
    res
  } else {
    NULL
  }
}

#' Convert data string
#'
#' Converte date from "dd.mm.yy" tp "20yy-mm-dd" or "dd.mm.yyyy" to "yyyy-mm-dd"
#'
#' @param dateString date string to convert
#'
#' @return converted \code{dateString}
rtkConvertDate <- function( dateString) {
  if ( is.na(dateString[1])) {
    return( NA)
  }

  re <-"([0-9][0-9])[.]([0-9][0-9])[.]([0-9]*)"
  match <- regexpr( re, dateString, perl=TRUE)
  if ( length(attr( match, "capture.start")) != 3 ||
       attr( match, "capture.length")[1] != 2 ||
       attr( match, "capture.length")[2] != 2 ||
       (attr( match, "capture.length")[3] != 2 && attr( match, "capture.length")[3] != 4) ) {
    return ( dateString)
  } else {
    parts <- lapply( 1:3, function(i) {substr( dateString,
                                               attr( match, "capture.start")[i],
                                               attr( match, "capture.start")[i]+attr( match, "capture.length")[i]-1)
      })
    names(parts) <- c("day","month", "year")

    if ( attr( match, "capture.length")[3] == 2) {
      parts$year <- paste( "20", parts$year, sep="")
    }

    return ( paste( parts$year,parts$month,parts$day,sep="-"))
  }
}

#' Extract unit from a vector of (column) names
#'
#' Valid units are "pixel", "mm", "inch", "cm" and may appear at the end of each name,
#' optionally followed by the suffix "^2" or "^3".
#' In case differrent units are present a warning is print and NULL returned
#'
#' @param names Vector of strings
#'
#' @return The unit found in \code{names}
#' @export
#'
rtkExtractUnitFromNames <- function( names) {
  # we need some character which will NOT appear in any colname, and chose the semicolon, as this may be used
  # as a field separator
  re <- "(pixel|mm|cm|inch)(|[;^]2|[;^]3)$"
  hits <- regexpr( re, names, perl=TRUE)
  idx = (attr( hits, "capture.start")>=0)[,1]
  unitsFound <- substr( names[ idx], attr( hits, "capture.start")[idx],
                        attr( hits, "capture.start")[idx,1]+attr( hits, "capture.length")[idx,1]-1)

  if ( sum( unitsFound != unitsFound[1]) != 0) {
    warning( "found multiple units in column names ", unitsFound)
    return( NULL)
  }
  unitsFound[1]
}

#' Replace the specific units in a vector of (column) names
#'
#'  Replace the specific units in a vector of (column) names by the generic "UNIT".
#' The caret in the optional sufix "^2" or "^3" is replaced by "_".
#' For the format see \link{rtkExtractUnitFromNames}
#'
#' @param segDF data frame to replace column names
#' @return data frame with modified column names
#' @export
rtkToGenericUnit <- function( segDF) {
  colNames = names( segDF)
  origUnit <- rtkExtractUnitFromNames( colNames)
  colNames <- gsub( origUnit, "UNIT", colNames)
  colNames <- gsub( "\\^2$", "_2", colNames)
  colNames <- gsub( "\\^3$", "_3", colNames)
  names( segDF) <- colNames

  list( segDF=segDF, origUnit=origUnit)
}

#' Replace the generic "UNIT" in a vector of names
#'
#' Replace the generic "UNIT" in a vector of (column) names by the specific unit \code{origUnit}.
#' The _" in the optional sufix "_2" or "_3" is replaced by the caret.
#' For the format see \link{rtkExtractUnitFromNames}
#'

#' @param segDF data frame to replace column names
#' @param origUnit string with the original unit to replace
#'
#' @return data frame with modified column names
#' @export
rtkToSpecificUnit <- function( segDF, origUnit) {
  colNames = names( segDF)
  colNames <- gsub( "UNIT", origUnit, colNames)
  colNames <- gsub(  "_2$", "\\^2", colNames)
  colNames <- gsub(  "_3$", "\\^3", colNames)
  names( segDF) <- colNames

  segDF
}

#' Aggregate a rhizoTrak csv file in detailed mode
#'
#' Aggregate the experimental data annotated with rhizoTrak written to a csv file in detailed mode at the root level
#'
#' If \code{byStatus} is false, all segments of each treelines are aggregated, i.e. sharing
#' the same \code{rootID} and \code{layerID}.
#' If \code{byStatus} is true, only segments of a treeline with the same status label are aggregated.
#' I.e. all segments are aggregated which share the same rootID\code{, }layerID\code{, and }status'.
#' If \code{status} is non negative segments with this numerical identifier of the segment status label are aggreageted
#' otherwise all status labels present in the data frame.
#'
#' In all cases the result is return as one data frame which subsumes the columns
#' \code{experiment}, \code{tube}, \code{timepoint}, \code{date}, \code{rootID}, and \code{layerID}.
#' These columns have the same values as in the input data frame.
#' According to the semantics, the columns \code{experiment}, \code{tube}, \code{timepoint}, and \code{date} should be
#' identical for all segments of the same treeline, i.e. segements sharing the same \code{rootID} and \code{layerID}.
#' If this is not the case \code{rtkAggregateRoots} uses the values of the first segment in the data frame.
#' If the csv file has
#' been generated by rhizoTrak  the first four
#' columns have sensible values only if the filename of the annotated images  adher to the ICAP naming
#' convention (see the User's guide for details).
#'
#' Independent of the value of \code{byStatus} the following columns are added:
#'
#' \code{dateYYYYMMDD}: the date specified in the \code{date} column reformated to YYYY-MM-DD
#'
#' \code{length_UNIT}: the sum of the lengths of the segments
#' \code{avg_diameter_UNIT}: the average diameter of the aggregated segments; the average diameter of one segment is computed as the mean of start and end diameter. These are averaged over the segments weihgted by the length of the segments
#'
#' \code{surfaceArea_UNIT^2}: the sum of the surface areas of the segments
#' \code{volume_UNIT^3}: the sum of the volumes of the segments
#'
#'
#' The \code{UNIT} is substituted by the unit as found in the column names of the input data frame.
#'
#' If segements are aggregated regardless of their status (\code{byStatus} is false)
#' the following additional columns are generated
#'
#' \code{first_layerID}: the first \code{layerID} in which the physical root identified by \code{rootID} is present in the data frame
#' \code{number_branches}: the number of branches where for each non tip node the number of outgoing segments minus one is determined
#' \code{number_tips}: the number of tip nodes, i.e. the number of nodes with no out going segments
#'
#' If segements are aggreagated by their status (\code{byStatus} is true)
#' the following additional columns are generated
#'
#' \code{status}: the numerical identifier of the status label of all segments aggregated in this row
#' \code{status_Name}: the  name of this status label
#'
#'
#'
#' @param segDF data frame read from the experimental data annotated with rhizoTrak in Detailed mode
#' @param byStatus if FALSE the segments of each root are aggregated ignoring status labels, if TRUE  each root is aggregated by status labels
#' @param status if non negative aggregate only segment with this status (label), if negative aggregate all status labels
#'
#' @return the dataframe with data at the root level
#' @export
#' @author Stefan Posch <stefan.posch@informatik.uni-halle.de>
#' @examples
#' library(data.table)
#' segDF <- fread( system.file("extdata", "rhizoTrak_t23-detailed.csv", package = "rhizoTrakAddons"))
#' rootlevelDF <- rtkAggregateRoots( segDF)
#' rootlevelDF0 <- rtkAggregateRoots( segDF, byStatus=TRUE, status = 0)
#'
#' filename <- system.file("extdata", "rhizoTrak_t23-detailed.csv", package = "rhizoTrakAddons")
#' segDF2 <- read.csv( filename,
#'                  header = TRUE, sep="\t", check.names = FALSE)
#' rootlevelDF2 <- rtkAggregateRoots( segDF2)
#' @import dplyr
#' @importFrom rlang .data
rtkAggregateRoots <- function( segDF, byStatus=FALSE, status=NULL) {
  # beware: we cannot use status in, e.g., filter
  localStatus = status
  # aggregation for each status label present by recursive call
  if ( byStatus &&  localStatus < 0 ) {
    statusLabels <- rtkGetStatusLabels( segDF)$status
    return ( do.call( rbind, lapply( statusLabels, function(sl){
      rtkAggregateRoots( segDF, byStatus = TRUE, sl)
    })))
  }

  ## create final order of columns
  ## Note: additional columns need to be added here !!
  finalColOrder <- c("experiment", "tube", "timepoint", "date", "dateYYYYMMDD", "rootID", "layerID",
                     "length_UNIT", "avg_diameter_UNIT", "surfaceArea_UNIT_2", "volume_UNIT_3")
  if ( byStatus ){
    finalColOrder <- c( finalColOrder, "status", "statusName")
  } else {
    finalColOrder <- c( finalColOrder, "first_layerID", "number_branches", "number_tips")
  }

  # retrieve and replace specfic unit
  replaceResult <- rtkToGenericUnit( segDF)
  segDFUNIT <- replaceResult$segDF

  # aggregation for one status label, <status> non negative at this point
  if ( byStatus ){
    segDFUNIT <- filter( segDFUNIT, .data$status==localStatus)
  }

  # check if any rows are left
  if ( nrow(segDFUNIT) == 0) {
    return( rtkToSpecificUnit( segDFUNIT, replaceResult$origUnit))
  }

  # aggregate()
  if ( byStatus ) {
    groupedDF <-group_by( segDFUNIT, .data$rootID, .data$layerID, .data$status)
  } else {
    groupedDF <-group_by( segDFUNIT, .data$rootID, .data$layerID)
  }

  rootlevelDF <- groupedDF  %>%
    mutate( sum_diameter = .data$length_UNIT * (.data$startDiameter_UNIT + .data$endDiameter_UNIT)/2) %>%
    summarise( experiment = first(.data$experiment),
               tube = first( .data$tube),
               timepoint = first( .data$timepoint),
               date = first( .data$date),
               length_UNIT = sum( .data$length_UNIT),
               sum_diameter = sum( .data$sum_diameter),
               surfaceArea_UNIT_2 = sum(.data$surfaceArea_UNIT_2),
               volume_UNIT_3 = sum(.data$volume_UNIT_3),
               number_branches = as.integer( sum( max( .data$children-1,0))) ,
               number_tips = sum( .data$children == 0)) %>%
    mutate( avg_diameter_UNIT = .data$sum_diameter/.data$length_UNIT,
            dateYYYYMMDD = rtkConvertDate( .data$date)) %>%
    select( -.data$sum_diameter) %>% ungroup()


  # if aggregation for one time point, then add the status label
  # and drop topology
  if ( byStatus ){
    rootlevelDF <- mutate( rootlevelDF, status=localStatus, statusName=rtkGetNameForStatus( segDF, localStatus))
    rootlevelDF <- select( rootlevelDF, -.data$number_branches, -.data$number_tips)
  } else {
    # get first timepoint
    rootlevelDF <- rootlevelDF %>% group_by( .data$rootID) %>%
      mutate( first_layerID = as.integer( min(.data$timepoint)))
  }

  # reorder columns
  rootlevelDF <- rootlevelDF[,finalColOrder]

  # sort rows and convert back to specific unit
  rtkToSpecificUnit( arrange( rootlevelDF, .data$rootID, .data$timepoint), replaceResult$origUnit)
}
