## ----exa, echo=FALSE, fig.cap="**Fig 1.**  *Treeline representing an annotated root.*", out.width=400----
knitr:::include_graphics("treelines-example1.png")

## ----exa2, echo=FALSE, fig.cap="**Fig 2.** *Example of treelines in two layers, i.e. time points, sharing the same `rootID` and two different status labels represented by colors. The dashed line connects two treelines annotating the same phyical root*", out.width=400----
knitr:::include_graphics("treelines-example2.png")

## ---- eval=FALSE---------------------------------------------------------
#  library(rhizoTrakAddons)

